# Пакет AppLoginScreen v2

В пакете собраны 20 актуальных рекламных изображений для `AppLoginScreen`:

- `recruit1.jpg` … `recruit10.jpg` — реклама HUNT TECH;
- `recruit11.jpg` … `recruit20.jpg` — реклама HRM HuntTech.

Все файлы уже приведены к размеру `1161×700` и готовы к замене в каталоге:

```text
modules/web/web/VAADIN/brand-login-screen/
```
